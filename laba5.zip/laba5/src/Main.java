public class Main {
    public static void main(String[] args) {
        GUIForm dialog = new GUIForm();
        dialog.pack();
        dialog.setVisible(true);
        dialog.setName("laba1");
        System.exit(0);
    }

}